﻿using System;
using System.Net;
using System.Web;

namespace TradingTerminal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(TradingFunctions.SuperTrendAPICall(5, "BTC/USDT"));
            Console.WriteLine(TradingFunctions.GetCoinCourse(2, "BTC/USDT"));
            Console.WriteLine(TradingFunctions.SuperTrendFlatCheck("BTC/USDT"));
            Console.WriteLine(TradingFunctions.EntryPossitionCheck("BTC/USDT"));
        }
    }
}
