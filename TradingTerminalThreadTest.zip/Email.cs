﻿using System;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Mail;

namespace TradingTerminal
{
    public class Email
    {
        public static string mail = "omdizzaster@gmail.com";
        //public static string GetEmail()
        //{
        //string mail = textBox.Text.Trim();
        //return mail;
        //}
        
        public static void SendSignal(string mail, string messege)
        {
            if(Email.mail != "")
            {
                MailAddress from = new MailAddress("supertrendbot@outlook.com", "SuperTrendSignal");
                // кому отправляем
                MailAddress to = new MailAddress(mail);
                // создаем объект сообщения
                MailMessage m = new MailMessage(from, to);
                // тема письма
                m.Subject = "Сингал от бота";
                // текст письма
                m.Body = "<h2>" + messege + "</h2>";
                // письмо представляет код html
                m.IsBodyHtml = true;
                // адрес smtp-сервера и порт, с которого будем отправлять письмо
                SmtpClient smtp = new SmtpClient("smtp.outlook.com", 587);
                // логин и пароль
                smtp.Credentials = new NetworkCredential("supertrendbot@outlook.com", "12042003A");
                smtp.EnableSsl = true;
                smtp.Send(m);
            }
           
            
        }


    }


}
