﻿using System;
using System.Net;
using System.Web;
using System.Threading;
using System.IO;
using System.Timers;

namespace TradingTerminal
{
    public class Program
    {
        public string BTC ="";
        static void Main(string[] args)
        {
            string[] pairs = { "BTC/USDT", "ETH/USDT", "SOL/USDT", "XRP/USDT" , "LTC/USDT"};
            
            

            //Thread ThreadBTC = new Thread(ThreadView.ThreadOnAir);

            //ThreadBTC.Start(pairs[0]);
            /*
            Thread ThreadETH = new Thread(ThreadView.ThreadOnAir);
            ThreadETH.Start(pairs[1]);

            Thread ThreadSOL = new Thread(ThreadView.ThreadOnAir);
            ThreadSOL.Start(pairs[2]);

            Thread ThreadXRP = new Thread(ThreadView.ThreadOnAir);
            ThreadXRP.Start(pairs[3]);

            Thread ThreadLTC = new Thread(ThreadView.ThreadOnAir); 
            ThreadLTC.Start(pairs[4]);
            */
            //ThreadView.ThreadOnAir(pairs[0]);
            //ThreadView.ThreadOnAir(pairs[1]);

            //ThreadBTC.Start(pairs[0]);
            //Thread.Sleep(8000);
            //ThreadETH.Start(pairs[1]);
            //Thread.Sleep(8000);
            //ThreadSOL.Start(pairs[2]);
            //Thread.Sleep(8000);
            //ThreadXRP.Start(pairs[3]);
            //Thread.Sleep(8000);
            //ThreadLTC.Start(pairs[4]);




            //Console.WriteLine(TradingFunctions.SuperTrendAPICall(5, "BTC/USDT"));
            //Console.WriteLine(TradingFunctions.GetCoinCourse(2, "BTC/USDT"));
            Console.WriteLine(TradingFunctions.GetCoinCourse(2, "ETH/USDT"));
            //Console.WriteLine(TradingFunctions.GetCoinCourse(1, "SOL/USDT"));
            //Console.WriteLine(TradingFunctions.SuperTrendAPICall(5, "ETH/USDT"));
            //Console.WriteLine(TradingFunctions.SuperTrendFlatCheck("BTC/USDT"));
            //Console.WriteLine(TradingFunctions.EntryPossitionCheck("BTC/USDT"));

        }





    }
}
