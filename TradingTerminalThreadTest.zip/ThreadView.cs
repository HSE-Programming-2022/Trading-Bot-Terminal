﻿using System;
using System.Net;
using System.Web;
using System.Threading;
using System.IO;
using System.Timers;

namespace TradingTerminal
{
    class ThreadView
    {
        public static void ThreadOnAir(object obj)
        {
            
            Thread Pair = new Thread(TradingFunctions.Request);

            
            Pair.Start(obj);
            

            Thread.Sleep(30000);
            Pair.Interrupt();
            
           
            ThreadOnAir(obj);
        }
    }
}
